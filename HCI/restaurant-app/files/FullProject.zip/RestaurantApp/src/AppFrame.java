/**
 * Created by Benji Snith on 2/19/2015.
 */

import javafx.scene.control.RadioButton;

import java.awt.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.BorderUIResource;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import static javax.swing.plaf.BorderUIResource.BevelBorderUIResource;

public class AppFrame extends JFrame{

    public AppFrame() {
        initUI();
    }

    private void initUI() {
        JLabel menuTitle = new JLabel();

        JLabel iconLabel = new JLabel("Icon should be here.");

        java.net.URL imageURL = AppFrame.class.getResource("icons/icon.png");
        if (imageURL != null) {
            ImageIcon logoIcon = new ImageIcon(imageURL);
            if(logoIcon != null) {
                iconLabel = new JLabel(logoIcon);
            }
        }

        ImageIcon callIcon = null;
        java.net.URL phoneURL = AppFrame.class.getResource("icons/phone.png");
        if (phoneURL != null) {
            callIcon = new ImageIcon(phoneURL);
        }
        JButton callButton = new JButton("Phone");
        if(callIcon != null){
            callButton = new JButton(callIcon);
        }
        callButton.setMaximumSize(new Dimension(64, 64));
        callButton.setMinimumSize(new Dimension(64, 64));
        callButton.setToolTipText("Push to call store");

        JButton placeOrder = new JButton("Place Order");

        JLabel titleLabel = new JLabel("RantRest Menu");
        titleLabel.setFont(new Font(titleLabel.getFont().getName(), Font.PLAIN, 30));

        JCheckBox hotCheckBox = new JCheckBox("Extra hot?");

        JComboBox menuComboBox = new JComboBox();
        menuComboBox.setMaximumSize(new Dimension(200, 50));
        menuComboBox.addItem("Chicken dinner");
        menuComboBox.addItem("Pasta salad");

        TitledBorder border = new TitledBorder("Border.");

        JPanel diningOptions = new JPanel(new GridLayout(3,1));
        diningOptions.setBorder(border);
        JRadioButtonMenuItem pickup   = new JRadioButtonMenuItem("Pick-Up");
        pickup.setSelected(true);
        JRadioButtonMenuItem delivery = new JRadioButtonMenuItem("Delivery");
        JRadioButtonMenuItem eatIn    = new JRadioButtonMenuItem("Eat-In");

        pickup.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                delivery.setSelected(false);
                eatIn.setSelected(false);
            }
        });

        delivery.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                pickup.setSelected(false);
                eatIn.setSelected(false);
            }
        });

        eatIn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                delivery.setSelected(false);
                pickup.setSelected(false);
            }
        });

        diningOptions.setMaximumSize(new Dimension(100, 100));
        diningOptions.setToolTipText("Select a Dining Option");

        diningOptions.add(pickup);
        diningOptions.add(delivery);
        diningOptions.add(eatIn);

        JTextField cardNumber = new JTextField("Enter card number");
        cardNumber.setMaximumSize(new Dimension(200, 30));
        cardNumber.setMinimumSize(new Dimension(200, 30));

        JCheckBox payWithCash = new JCheckBox("Pay with cash?");
        payWithCash.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if(payWithCash.isSelected()){
                    cardNumber.setBackground(new Color(200,200,200));
                    cardNumber.setEnabled(false);
                }
                else{
                    cardNumber.setBackground(new Color(255,255,255));
                    cardNumber.setEnabled(true);
                }
            }
        });




        //-----------------------Layout Setup--------------------------
        Container pane = getContentPane();
        GroupLayout gl = new GroupLayout(pane);
        pane.setLayout(gl);

        gl.setAutoCreateContainerGaps(true);
        gl.setAutoCreateGaps(true);

        gl.setHorizontalGroup(gl.createSequentialGroup()
                        .addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(iconLabel)
                                .addComponent(hotCheckBox)
                                .addComponent(payWithCash))
                        .addGap(50)
                        .addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(titleLabel)
                                .addComponent(menuComboBox)
                                .addComponent(cardNumber))
                        .addGap(270)
                        .addGroup(gl.createParallelGroup(GroupLayout.Alignment.TRAILING)
                                .addComponent(diningOptions)
                                .addComponent(callButton)
                                .addComponent(placeOrder))
        );


        gl.setVerticalGroup(gl.createSequentialGroup()
                        .addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(iconLabel)
                                .addComponent(titleLabel))
                        .addGap(50)
                        .addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(hotCheckBox)
                                .addComponent(menuComboBox)
                                .addComponent(diningOptions))
                        .addComponent(callButton)
                        .addGap(50)
                        .addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                                .addComponent(payWithCash)
                                .addComponent(cardNumber))
                        .addGap(50)
                        .addComponent(placeOrder)
        );

        pack();

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("File");
        menuBar.add(menu);

        JMenuItem item1 = new JMenuItem("Save");
        JMenuItem item2 = new JMenuItem("Quit");

        item1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.out.println("Save the menu.  Not yet implemented.");
            }
        });

        item2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.exit(0);
            }
        });

        menu.add(item1);
        menu.add(item2);

        setJMenuBar(menuBar);

        setTitle("RantRest Ordering App");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}
