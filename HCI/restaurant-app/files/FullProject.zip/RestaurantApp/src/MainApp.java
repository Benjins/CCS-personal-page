/**
 * Created by Benji Snith on 2/19/2015.
 */

import java.awt.EventQueue;
import javax.swing.JApplet;

public class MainApp extends JApplet{

    public static void main(String[] args) {

        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                AppFrame ex = new AppFrame();
                ex.setVisible(true);
            }
        });
    }
}
