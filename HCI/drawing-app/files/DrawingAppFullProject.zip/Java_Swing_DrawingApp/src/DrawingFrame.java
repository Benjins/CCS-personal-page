import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;

/**
 * Created by Benji Snith on 3/1/2015.
 */

public class DrawingFrame extends JFrame {
    ArrayList<Shape> shapeList = new ArrayList<Shape>();
    java.awt.Color currentCol = Color.RED;
    ShapeType currentType = ShapeType.Rect;
    int currentLineWidth = 1;
    boolean dragging = false;

    public DrawingFrame() {
        initUI();
    }

    private void initUI() {
        JPanel canvas = new JPanel(){
            @Override
            public void paintComponent(Graphics g) {
                super.paintComponent(g);
                //System.out.println("paint");

                for(Shape shape : shapeList){
                    shape.Draw(g);
                }
            }
        };

        canvas.setPreferredSize(new Dimension(700,500));

        canvas.addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent mouseEvent) {
                if(dragging) {
                    shapeList.get(shapeList.size() - 1).SetNewCorner(mouseEvent.getX(), mouseEvent.getY());
                    DrawingFrame.this.repaint();
                }
            }

            @Override
            public void mouseMoved(MouseEvent mouseEvent) {

            }
        });

        canvas.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent mouseEvent) {
            }

            @Override
            public void mousePressed(MouseEvent mouseEvent) {
                shapeList.add(Shape.ChooseShape(currentType, mouseEvent.getX(), mouseEvent.getY(), currentCol, currentLineWidth));
                dragging = true;
                //System.out.println("added shape");
            }

            @Override
            public void mouseReleased(MouseEvent mouseEvent) {
                dragging = false;
            }

            @Override
            public void mouseEntered(MouseEvent mouseEvent) {}

            @Override
            public void mouseExited(MouseEvent mouseEvent) {}
        });

        final JComboBox shapeChoice = new JComboBox();
        shapeChoice.setMaximumSize(new Dimension(80, 30));
        shapeChoice.addItem(ShapeType.Rect);
        shapeChoice.addItem(ShapeType.Oval);
        shapeChoice.addItem(ShapeType.Line);
        shapeChoice.addItem(ShapeType.Arc);
        shapeChoice.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                currentType = (ShapeType)shapeChoice.getSelectedItem();
            }
        });

        final JComboBox colorChoice = new JComboBox();
        colorChoice.setMaximumSize(new Dimension(80, 30));
        colorChoice.addItem("Red");
        colorChoice.addItem("Green");
        colorChoice.addItem("Blue");
        colorChoice.addItem("Yellow");
        colorChoice.addItem("Cyan");
        colorChoice.addItem("Grey");

        colorChoice.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                String choice = colorChoice.getSelectedItem().toString();
                if(choice.equals("Red")){
                    currentCol = Color.red;
                }
                else if(choice.equals("Green")){
                    currentCol = Color.green;
                }
                else if(choice.equals("Blue")){
                    currentCol = Color.blue;
                }
                else if(choice.equals("Yellow")){
                    currentCol = Color.yellow;
                }
                else if(choice.equals("Cyan")){
                    currentCol = Color.cyan;
                }
                else if(choice.equals("Grey")){
                    currentCol = Color.lightGray;
                }
            }
        });

        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                shapeList.clear();
                canvas.repaint();
            }
        });

        JLabel lineWidthLabel = new JLabel("Line Width: 1");

        JSlider lineWidth = new JSlider();
        lineWidth.setMinimum(1);
        lineWidth.setMaximum(32);
        lineWidth.setToolTipText("Width of lines and arcs");
        lineWidth.setValue(1);
        lineWidth.setMinimumSize(new Dimension(60,20));
        lineWidth.setMaximumSize(new Dimension(60, 20));
        lineWidth.setOrientation(JSlider.HORIZONTAL);
        lineWidth.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent changeEvent) {
                currentLineWidth = lineWidth.getValue();
                lineWidthLabel.setText("Line Width: " + lineWidth.getValue());
            }
        });

        Container pane = getContentPane();
        GroupLayout gl = new GroupLayout(pane);
        pane.setLayout(gl);

        gl.setAutoCreateContainerGaps(true);
        gl.setAutoCreateGaps(true);

        gl.setHorizontalGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                        .addGroup(gl.createSequentialGroup()
                                        .addComponent(clearButton)
                                        .addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(lineWidthLabel)
                                        .addComponent(lineWidth)
                                        .addComponent(colorChoice)
                                        .addComponent(shapeChoice)
                        )
                        .addComponent(canvas)

        );

        gl.setVerticalGroup(gl.createSequentialGroup()
                                    .addGroup(gl.createParallelGroup(GroupLayout.Alignment.LEADING)
                                                    .addComponent(clearButton)
                                                    .addComponent(lineWidthLabel)
                                                    .addComponent(colorChoice)
                                                    .addComponent(shapeChoice)
                                                    .addComponent(lineWidth)
                                    )
                        .addComponent(canvas)
        );

        JMenuBar menuBar = new JMenuBar();
        JMenu menu = new JMenu("File");
        menuBar.add(menu);

        JMenuItem item3 = new JMenuItem("Undo");
        JMenuItem item1 = new JMenuItem("Save");
        JMenuItem item2 = new JMenuItem("Clear");
        JMenuItem item4 = new JMenuItem("Quit");

        item1.setAccelerator(
                KeyStroke.getKeyStroke(
                        KeyEvent.VK_S,
                        InputEvent.CTRL_DOWN_MASK
                ));
        item1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setAcceptAllFileFilterUsed(false);
                fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);

                FileNameExtensionFilter filter = new FileNameExtensionFilter("PNG image file", "png");
                fileChooser.addChoosableFileFilter(filter);
                if (fileChooser.showSaveDialog(canvas) == JFileChooser.APPROVE_OPTION) {
                    File fileToBeSaved = fileChooser.getSelectedFile();

                    if(!fileChooser.getSelectedFile().getAbsolutePath().endsWith(".png")){
                        fileToBeSaved = new File(fileChooser.getSelectedFile() + ".png");
                    }
                    System.out.println(fileToBeSaved.getAbsolutePath());

                    BufferedImage img = new BufferedImage(
                            canvas.getWidth(),
                            canvas.getHeight(),
                            BufferedImage.TYPE_INT_RGB
                    );

                    canvas.paint(img.getGraphics());

                    try {
                        // write the image as a PNG
                        ImageIO.write(
                                img,
                                "png",
                                fileToBeSaved);
                    } catch(Exception e) {
                        e.printStackTrace();
                    }

                }
            }
        });

        //item2.setAccelerator();
        item2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                shapeList.clear();
                canvas.repaint();
            }
        });

        item3.setAccelerator(
                KeyStroke.getKeyStroke(
                        KeyEvent.VK_Z,
                        InputEvent.CTRL_DOWN_MASK
                ));
        item3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if(shapeList.size() > 0) {
                    shapeList.remove(shapeList.size() - 1);
                    canvas.repaint();
                }
            }
        });

        item4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.exit(0);
            }
        });

        menu.add(item1);
        menu.add(item2);
        menu.add(item3);
        menu.add(item4);

        setJMenuBar(menuBar);

        setTitle("Drawing App");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }
}

