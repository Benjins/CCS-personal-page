import javax.swing.*;
import java.awt.*;

/**
 * Created by Benji Snith on 3/1/2015.
 */
public class MainApp extends JApplet {
    public static void main(String[] args) {

        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                DrawingFrame ex = new DrawingFrame();
                ex.setVisible(true);
            }
        });
    }
}
