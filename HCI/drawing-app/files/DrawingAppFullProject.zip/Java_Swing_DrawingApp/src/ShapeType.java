import java.awt.*;

/**
 * Created by Benji Snith on 3/1/2015.
 */

public enum ShapeType{
    Rect,
    Oval,
    Arc,
    Line
}

abstract class Shape{
    int x, y;
    java.awt.Color col;

    public abstract void SetNewCorner(int mouseX, int mouseY);

    public abstract void Draw(Graphics g);

    public static Shape ChooseShape(ShapeType type, int x, int y, java.awt.Color col, int lineWidth){
        if(type == ShapeType.Rect){
            return new Rectangle(x,y,col);
        }
        else if(type == ShapeType.Oval){
            return new Circle(x,y,col);
        }
        else if(type == ShapeType.Line){
            return new Line(x,y,col, lineWidth);
        }
        else if(type == ShapeType.Arc){
            return new Arc(x,y,col, lineWidth);
        }
        else{
            return null;
        }
    }
}

class Rectangle extends Shape{


    int startX, startY;
    int width=0,height=0;

    public Rectangle(int x, int y, java.awt.Color col){
        this.x = x;
        this.y = y;
        this.startX = x;
        this.startY = y;
        this.col = col;
    }

    @Override
    public void SetNewCorner(int mouseX, int mouseY){
        x = Math.min(mouseX, startX);
        y = Math.min(mouseY, startY);

        width  = Math.abs(mouseX - startX);
        height = Math.abs(mouseY - startY);
    }

    @Override
    public void Draw(Graphics g) {
        g.setColor(col);
        g.fillRect(x, y, width, height);
    }
}

class Circle extends Shape{
    int width=0, height=0;
    final int startX, startY;

    public Circle(int x, int y, java.awt.Color col){
        this.x = x;
        this.y = y;
        this.startX = x;
        this.startY = y;
        this.col = col;
    }

    @Override
    public void SetNewCorner(int mouseX, int mouseY) {
        x = Math.min(mouseX, startX);
        y = Math.min(mouseY, startY);

        width  = Math.abs(mouseX - startX);
        height = Math.abs(mouseY - startY);
    }

    @Override
    public void Draw(Graphics g) {
        g.setColor(col);
        g.fillOval(x, y, width, height);
    }
}

class Line extends Shape{
    int endX=0, endY=0;
    int lineWidth=1;

    public Line(int x, int y, java.awt.Color col, int lineWidth){
        this.x = x;
        this.y = y;
        this.col = col;
        this.lineWidth = lineWidth;
    }

    @Override
    public void SetNewCorner(int mouseX, int mouseY) {
        endX = mouseX;
        endY = mouseY;
    }

    @Override
    public void Draw(Graphics g) {
        Graphics2D gCast = (Graphics2D)g;
        gCast.setStroke(new BasicStroke(lineWidth));
        g.setColor(col);
        g.drawLine(x,y,endX,endY);
    }
}

class Arc extends Circle{
    int lineWidth=1;

    public Arc(int x, int y, java.awt.Color col, int lineWidth){
        super(x, y, col);
        this.lineWidth = lineWidth;
    }

    @Override
    public void Draw(Graphics g) {
        Graphics2D gCast = (Graphics2D)g;
        gCast.setStroke(new BasicStroke(lineWidth));
        g.setColor(col);


        int startAngle = -45;
        if(x > startX){
            if(y > startY){
                startAngle = -135;
            }
            else{
                startAngle = -45;
            }

        }
        else{
            if(y > startY){
                startAngle = 135;
            }
            else{
                startAngle = 45;
            }
        }

        g.drawArc(x, y, width, height, startAngle, 180);
    }
}

