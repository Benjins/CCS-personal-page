import javafx.scene.control.ScrollBar;
import javafx.scene.input.KeyCode;

import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreePath;
import java.awt.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by Benji Snith on 4/5/2015.
 */
public class MainFrame extends JPanel {

    JPanel startScreen = new JPanel();
    FileChange[] fileChanges;

    public MainFrame(){
        String cwdPath = System.getProperty("user.dir");
        File exampleFile = new File(cwdPath + File.separator + "PaperVC.iml");

        Change[] changes = {new Change("Hello", "Goodbye", 3),
                new Change("The only way", "One of several ways", 17),
                new Change("we felt is was better", "the data we found aren't good", 21)};

        FileChange[] newFileChanges = {  new FileChange(exampleFile, changes), new FileChange(exampleFile, changes),
                new FileChange(exampleFile, changes), new FileChange(exampleFile, changes)};

        fileChanges = newFileChanges;
        initUI();
    }

    public void initUI(){
        add(startScreen);
        JPanel changesPanel = new JPanel();
        JPanel leftBar = new JPanel();
        leftBar.setPreferredSize(new Dimension(150, 0));
        JPanel rightBar = new JPanel();

        startScreen.setLayout(new BorderLayout());
        startScreen.add(leftBar,      BorderLayout.WEST);
        startScreen.add(changesPanel, BorderLayout.CENTER);
        startScreen.add(rightBar,     BorderLayout.EAST);

        BoxLayout leftBarBoxLyt = new BoxLayout(leftBar, BoxLayout.Y_AXIS);
        leftBar.setLayout(leftBarBoxLyt);
        JButton historyButton = new JButton("History");
        historyButton.setPreferredSize(new Dimension(100, 30));
        historyButton.setToolTipText("See the history of this project.");
        historyButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                AppFrame.instance.SwitchPanels();
            }
        });

        DefaultMutableTreeNode topNode = new DefaultMutableTreeNode("Project Explorer");
        JTree projectExplorer = new JTree(topNode);
        projectExplorer.setPreferredSize(new Dimension(150, 100));
        projectExplorer.setRootVisible(true);

        String cwdPath = System.getProperty("user.dir");
        File currentDir = new File(cwdPath);
        ArrayList<DefaultMutableTreeNode> cwdFiles = listFilesForFolder(currentDir);
        for(DefaultMutableTreeNode node : cwdFiles){
            topNode.add(node);
        }

        JScrollPane projectExplorerWrapper = new JScrollPane(projectExplorer);
        projectExplorerWrapper.setPreferredSize(new Dimension(140, 100));
        projectExplorerWrapper.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        projectExplorerWrapper.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        leftBar.add(projectExplorerWrapper);
        leftBar.add(Box.createVerticalGlue());
        leftBar.add(historyButton);
        leftBar.add(Box.createVerticalGlue());

        changesPanel.setMinimumSize(new Dimension(600,0));
        changesPanel.setLayout(new BorderLayout());
        changesPanel.add(Box.createVerticalStrut(15));

        changesPanel.add(Box.createVerticalStrut(15), BorderLayout.NORTH);
        changesPanel.add(Box.createHorizontalStrut(15), BorderLayout.WEST);
        changesPanel.add(Box.createHorizontalStrut(15), BorderLayout.EAST);

        JPanel changesList = new JPanel();
        changesList.setBorder(new TitledBorder("Current Changes:"));
        changesPanel.add(changesList, BorderLayout.CENTER);

        changesList.setLayout(new GridLayout(0, 1));

        for(FileChange change : fileChanges){
            JPanel changePanel = new JPanel();
            changePanel.setLayout(new BoxLayout(changePanel, BoxLayout.X_AXIS));
            try {
                JPanel subFileChanges = new JPanel(new BorderLayout());
                subFileChanges.add(new JLabel("Changes:"), BorderLayout.NORTH);

                JPanel subFileChangeList = new JPanel();
                subFileChangeList.setLayout(new BoxLayout(subFileChangeList, BoxLayout.Y_AXIS));
                subFileChanges.add(subFileChangeList, BorderLayout.CENTER);
                for(Change subChange : change.changes){
                    subFileChangeList.add(new JLabel("Line " + subChange.line + ":  "
                            + subChange.after.substring(0, Math.min(15, subChange.after.length())) + ((subChange.after.length() < 15)? "" : "...")));
                }

                changePanel.add(new JLabel("File:  " + change.file.getCanonicalPath()));
                changePanel.add(Box.createHorizontalStrut(50));
                changePanel.add(subFileChanges);
            } catch (IOException e) {
                continue;
            }
            changesList.add(changePanel);
            changesList.add(Box.createVerticalStrut(6));
        }

        rightBar.setLayout(new BoxLayout(rightBar, BoxLayout.Y_AXIS));
        JButton snapshotButton = new JButton("Create Snapshot");
        rightBar.add(snapshotButton);

        rightBar.add(Box.createVerticalStrut(20));
        JTextField message = new JTextField("Description...");
        message.setMaximumSize(new Dimension(150, 20));
        rightBar.add(message);
        rightBar.add(Box.createVerticalStrut(20));

        snapshotButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                if(!message.getText().equals("Description...")){
                    System.out.println("Created snapshot with description: " + message.getText());
                    fileChanges = new FileChange[0];
                    changesList.removeAll();
                    changesList.repaint();
                }
                else{
                    JDialog descriptionDialog = new JDialog();
                    descriptionDialog.setSize(300,150);
                    descriptionDialog.setLocationRelativeTo(null);
                    descriptionDialog.setLayout(new BorderLayout());

                    descriptionDialog.add(new JLabel("Please enter a description."), BorderLayout.NORTH);
                    JTextArea description = new JTextArea();
                    description.setPreferredSize(new Dimension(180, 50));
                    descriptionDialog.add(description, BorderLayout.CENTER);

                    JButton okButton = new JButton("OK");
                    descriptionDialog.add(okButton, BorderLayout.SOUTH);

                    okButton.addActionListener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent actionEvent) {
                            if(description.getText().length() > 0) {
                                System.out.println("Created snapshot with description: " + description.getText());
                                fileChanges = new FileChange[0];
                                changesList.removeAll();
                                changesList.repaint();

                                descriptionDialog.setVisible(false);
                            }
                        }
                    });

                    description.addKeyListener(new KeyListener() {
                        @Override
                        public void keyTyped(KeyEvent keyEvent) {}

                        @Override
                        public void keyPressed(KeyEvent keyEvent) {}

                        @Override
                        public void keyReleased(KeyEvent keyEvent) {
                            if(keyEvent.getKeyCode() == KeyEvent.VK_ENTER){
                                System.out.println("Created snapshot with description: " + description.getText());
                                fileChanges = new FileChange[0];
                                changesList.removeAll();
                                changesList.repaint();

                                descriptionDialog.setVisible(false);
                            }
                        }
                    });
                    descriptionDialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    descriptionDialog.setVisible(true);
                }
            }
        });

        JPanel infoPanel = new JPanel(new GridLayout(3,1));
        infoPanel.add(new JLabel("Info:"));

        JLabel fileLabel = new JLabel("File:");
        infoPanel.add(fileLabel);

        infoPanel.add(new JLabel("Changes: --"));

        rightBar.add(infoPanel);
        rightBar.add(Box.createGlue());

        projectExplorer.addTreeSelectionListener(new TreeSelectionListener() {
            @Override
            public void valueChanged(TreeSelectionEvent treeSelectionEvent) {
                TreePath currPath = treeSelectionEvent.getNewLeadSelectionPath();

                if(currPath != null){
                    Object[] path = currPath.getPath();
                    String pathStr = "";
                    for(int i = 1; i < path.length; i++){
                        Object obj = path[i];
                        pathStr = pathStr + obj + ((i == path.length - 1) ? "":File.separator);
                    }
                    fileLabel.setText("File: " + pathStr);
                }
                else{
                    fileLabel.setText("File:");
                }
            }
        });


    }

    public static ArrayList<DefaultMutableTreeNode> listFilesForFolder(final File folder) {
        ArrayList<DefaultMutableTreeNode> files = new ArrayList<DefaultMutableTreeNode>();

        for (final File fileEntry : folder.listFiles()) {
            if (fileEntry.isDirectory()) {
                DefaultMutableTreeNode subFolder = new DefaultMutableTreeNode(fileEntry.getName());
                ArrayList<DefaultMutableTreeNode> subFiles = listFilesForFolder(fileEntry);
                for(DefaultMutableTreeNode subFile : subFiles){
                    subFolder.add(subFile);
                }
                files.add(subFolder);
            } else {
                files.add(new DefaultMutableTreeNode(fileEntry.getName()));
            }
        }

        return files;
    }
}
