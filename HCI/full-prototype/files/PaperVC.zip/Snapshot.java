import javax.print.attribute.DateTimeSyntax;
import java.io.File;
import java.util.Date;

/**
 * Created by Benji Snith on 4/5/2015.
 */

class Change{
    String before;
    String after;
    int line;

    Change(String before, String after, int line){
        this.before = before;
        this.after = after;
        this.line = line;
    }
}

class FileChange{
    File file;
    Change[] changes;

    FileChange(File file, Change[] changes){
        this.file = file;
        this.changes = changes;
    }

    public void addChange(Change change){
        Change[] newChanges = new Change[changes.length + 1];
        for(int i = 0; i < changes.length; i++){
            newChanges[i] = changes[i];
        }

        newChanges[changes.length] = change;

        changes = newChanges;
    }
}

public class Snapshot {
    String author;
    Date date;
    FileChange[] changes;

    Snapshot(String author, Date date, FileChange[] changes){
        this.author = author;
        this.date = date;
        this.changes = changes;
    }

    public void addChange(FileChange change){
        FileChange[] newChanges = new FileChange[changes.length + 1];
        for(int i = 0; i < changes.length; i++){
            newChanges[i] = changes[i];
        }

        newChanges[changes.length] = change;

        changes = newChanges;
    }
}
