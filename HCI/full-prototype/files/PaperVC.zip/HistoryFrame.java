import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import java.io.File;
import java.time.Instant;
import java.util.Date;

/**
 * Created by Benji Snith on 4/5/2015.
 */
public class HistoryFrame extends JPanel {

    Integer clickedIndex = -1;

    JLabel infoAuthor;
    JLabel infoDate;

    HistoryFrame(){
        initUI();
    }

    void initUI(){
        JPanel historyPanel = new JPanel();
        JPanel sideBar = new JPanel();

       //sideBar.setBackground(new Color(244, 52, 96));
       //historyPanel.setBackground(new Color(128, 73, 0));

        setLayout(new BorderLayout());
        add(historyPanel, BorderLayout.CENTER);
        add(sideBar, BorderLayout.EAST);

        sideBar.setLayout(new BoxLayout(sideBar, BoxLayout.Y_AXIS));
        sideBar.add(Box.createVerticalStrut(10));
        JButton backToChanges = new JButton("Back to Changes");
        backToChanges.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                AppFrame.instance.SwitchPanels();
            }
        });
        sideBar.add(backToChanges);
        sideBar.add(Box.createVerticalStrut(100));

        JPanel infoPanel = new JPanel();
        sideBar.add(infoPanel);
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
        infoPanel.add(new JLabel("Info:"));

        infoAuthor = new JLabel("Author:");
        infoPanel.add(infoAuthor);
        infoDate = new JLabel("Date:");
        infoPanel.add(infoDate);

        Snapshot[] snapShots =  new Snapshot[]{new Snapshot("John Smith",
                                              Date.from(Instant.now()),
                                              new FileChange[]{new FileChange(new File("test.txt"),
                                                               new Change[]{new Change("The first way", "The second way", 13)})}),
                                new Snapshot("Benji Smith",
                                        Date.from(Instant.now()),
                                        new FileChange[]{new FileChange(new File("test.txt"),
                                                new Change[]{new Change("was a great idea", "become a goo means", 13)})}),
                                new Snapshot("Marek Potomek",
                                        Date.from(Instant.now()),
                                        new FileChange[]{new FileChange(new File("test.txt"),
                                                new Change[]{new Change("We found the one", "", 13)})}),
                                new Snapshot("Salwen Vei'ir",
                                        Date.from(Instant.now()),
                                        new FileChange[]{new FileChange(new File("test.txt"),
                                                new Change[]{new Change("", "The previous example had", 13)})})};

        historyPanel.setLayout(null);

        RecalculateHistoryPanel(snapShots, historyPanel);
    }

    void RecalculateHistoryPanel(Snapshot[] snapShots, JPanel historyPanel){
        for(int i = 0; i < snapShots.length; i++){
            final int iter = i;
            Snapshot snapShot = snapShots[i];


            JPanel snapShotPanel = new JPanel();
            historyPanel.add(snapShotPanel);

            MouseListener clickAway = new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent mouseEvent) {
                    clickedIndex = -1;
                    for (int j = 0; j < snapShots.length; j++) {
                        historyPanel.getComponent(j).setBounds(0, 80 * (snapShots.length - 1 - j), 600, 140);
                        historyPanel.getComponent(j).setBackground(Color.white);
                    }
                }

                @Override
                public void mousePressed(MouseEvent mouseEvent) {}
                @Override
                public void mouseReleased(MouseEvent mouseEvent) {}
                @Override
                public void mouseEntered(MouseEvent mouseEvent) {}
                @Override
                public void mouseExited(MouseEvent mouseEvent) {}
            };

            historyPanel.addMouseListener(clickAway);

            snapShotPanel.addMouseListener(new MouseListener() {
                @Override
                public void mouseClicked(MouseEvent mouseEvent) {
                    for(int j = 0; j < snapShots.length; j++){
                        historyPanel.getComponent(iter).setBackground(Color.white);
                        if(j < iter){
                            historyPanel.getComponent(j).setBounds(0, 80 * (snapShots.length - 1-j) + 60, 600, 140);
                        }
                        else{
                            historyPanel.getComponent(j).setBounds(0, 80 * (snapShots.length - 1-j), 600, 140);
                        }
                    }

                    infoAuthor.setText("Author: " + snapShots[iter].author);
                    infoDate.setText("Date:  " + snapShots[iter].date.toString());

                    clickedIndex = iter;
                    historyPanel.getComponent(iter).setBackground(new Color(189, 211, 214));
                }

                @Override
                public void mousePressed(MouseEvent mouseEvent) {}

                @Override
                public void mouseReleased(MouseEvent mouseEvent) {}

                @Override
                public void mouseEntered(MouseEvent mouseEvent) {
                    if(clickedIndex >= 0){
                        return;
                    }
                    for(int j = 0; j < snapShots.length; j++){
                        if(j < iter){
                            historyPanel.getComponent(j).setBounds(0, 80 * (snapShots.length - 1-j) + 60, 600, 140);
                        }
                        else{
                            historyPanel.getComponent(j).setBounds(0, 80 * (snapShots.length - 1-j), 600, 140);
                        }

                    }
                }

                @Override
                public void mouseExited(MouseEvent mouseEvent) {
                    if(clickedIndex >= 0){
                        return;
                    }
                    for(int j = 0; j < snapShots.length; j++){
                        historyPanel.getComponent(j).setBounds(0, 80 * (snapShots.length - 1-j), 600, 140);
                    }
                }
            });

            snapShotPanel.setBounds(0, 80 * (snapShots.length - 1-i), 600, 140);
            //snapShotPanel.setBackground(new Color(120,120,30+i*60));
            snapShotPanel.setBorder(new TitledBorder("Snapshot " + i));
            snapShotPanel.setLayout(new BoxLayout(snapShotPanel, BoxLayout.Y_AXIS));

            JPanel infoHeader = new JPanel();
            infoHeader.add(new JLabel("Author: " + snapShot.author));
            infoHeader.add(new JLabel("Date: " + snapShot.date));
            snapShotPanel.add(infoHeader);

            for(int idx = 0; idx < snapShot.changes.length; idx++){
                JPanel changePanel = new JPanel();
                changePanel.add(new JLabel(snapShot.changes[idx].file.getName()));

                JLabel change1 = new JLabel(snapShot.changes[idx].changes[0].before);
                change1.setOpaque(true);
                change1.setBackground(new Color(255, 105, 100));
                changePanel.add(change1);

                JLabel change2 = new JLabel(snapShot.changes[idx].changes[0].after);
                change2.setOpaque(true);
                change2.setBackground(new Color(108, 255, 109));
                changePanel.add(change2);

                snapShotPanel.add(changePanel);
            }
        }
    }
}
