import javax.swing.*;
import java.awt.*;

/**
 * Created by Benji Snith on 4/5/2015.
 */
public class MainApp extends JApplet {
    public static void main(String[] args) {

        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                AppFrame ex = new AppFrame();
                ex.setSize(1000, 600);
                ex.setLocationRelativeTo(null);
                ex.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                ex.setLocationByPlatform(true);
                ex.setVisible(true);
            }
        });














    }
}
