import javax.swing.*;
import java.awt.*;

/**
 * Created by Benji Snith on 4/6/2015.
 */
public class AppFrame extends JFrame {

    static AppFrame instance; //bite me

    JPanel panel1;
    JPanel panel2;

    AppFrame(){
        instance = this;
        panel1 = new MainFrame();
        panel2 = new HistoryFrame();

        panel1.setVisible(true);
        panel2.setVisible(false);

        setLayout(null);

        panel1.setBounds(0,0,1000,600);
        panel2.setBounds(0,0,1000,600);
        add(panel1);
        add(panel2);
    }

    public void SwitchPanels(){
        panel1.setVisible(!panel1.isVisible());
        panel2.setVisible(!panel2.isVisible());
    }

}
