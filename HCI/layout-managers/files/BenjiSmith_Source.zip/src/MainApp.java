import javax.swing.*;
import java.awt.*;

/**
 * Created by Benji Snith on 3/25/2015.
 */
public class MainApp extends JApplet {
    public static void main(String[] args){
        EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {
                AppFrame ex = new AppFrame();
                ex.setName("PaperVC Proto");
                ex.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                ex.setVisible(true);
            }
        });
    }
}
