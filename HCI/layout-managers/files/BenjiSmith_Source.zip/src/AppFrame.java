import javax.swing.*;
import java.awt.*;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Created by Benji Snith on 3/25/2015.
 */
public class AppFrame extends JFrame {

    public AppFrame(){
        init();
        pack();
    }

    void init(){
        BorderLayout mainLayout = new BorderLayout(10,0);
        this.getContentPane().setLayout(mainLayout);

        JPanel leftBar = new JPanel();
        this.getContentPane().add(leftBar, BorderLayout.WEST);

        leftBar.setLayout(new BorderLayout(0,10));
        //JTree projectExplorer = new JTree();
        JTabbedPane projectExplorer = new JTabbedPane(JTabbedPane.TOP);
        projectExplorer.addTab("Project 1", new JLabel("This is project 1"));
        projectExplorer.addTab("Project 2", new JLabel("This is project 2"));
        projectExplorer.addTab("Project 3", new JLabel("This is project 3"));
        projectExplorer.setPreferredSize(new Dimension(200, 100));

        //JLabel projectExplorer = new JLabel("Project Explorer");
        leftBar.add(projectExplorer, BorderLayout.NORTH);

        JPanel leftBarRest = new JPanel();
        leftBar.add(leftBarRest, BorderLayout.CENTER);
        leftBarRest.setLayout(new BorderLayout());
        leftBarRest.add(new JButton("History"), BorderLayout.NORTH);

        JPanel rightBar = new JPanel();
        rightBar.setPreferredSize(new Dimension(100,300));
        this.getContentPane().add(rightBar, BorderLayout.EAST);

        rightBar.setLayout(new BorderLayout(0, 80));
        JButton snapshot = new JButton("Save Snapshot");
        rightBar.add(snapshot, BorderLayout.NORTH);

        JPanel rightBarRest = new JPanel();
        rightBarRest.setLayout(new BorderLayout(0, 80));

        JTextField descr = new JTextField("Description...");
        descr.setPreferredSize(new Dimension(150, 20));

        {
            //Create some component for the JDialog
            JButton okButton = new JButton("OK");
            JLabel dialogLabel = new JLabel("Enter a description");
            JTextField dialogDescr = new JTextField();
            dialogDescr.setPreferredSize(new Dimension(80,20));
            //Create the modeless dialog box
            // Using the JFrame tokenFrame as the parent component
            // allows the dialog to be centered in front of the frame
            JDialog dialog = new JDialog(this, "Click a button");
            dialog.setSize(200,80);
            dialog.setLayout(new BorderLayout(10,10));

            JPanel dialogBottom = new JPanel();

            dialog.add(dialogLabel, BorderLayout.NORTH);
            dialog.add(dialogBottom, BorderLayout.CENTER);
            dialogBottom.add(dialogDescr);
            dialogBottom.add(okButton);
            dialog.setVisible(false);
            dialog.pack();

            okButton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {
                    System.out.println("Made a revision!");
                    dialogDescr.setText("");
                    dialog.setVisible(false);
                }
            });

            snapshot.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent actionEvent) {
                    if(descr.getText().equals("Description...")) {
                        dialog.setVisible(true);
                    }
                    else{
                        System.out.println("Made a revision!");
                    }
                }
            });

        }



        rightBarRest.add(descr, BorderLayout.NORTH);

        JPanel rightBarBottom = new JPanel(new BorderLayout(0, 30));
        rightBarBottom.add(new JLabel("Info"), BorderLayout.NORTH);

        rightBarRest.add(rightBarBottom, BorderLayout.CENTER);

        rightBar.add(rightBarRest, BorderLayout.CENTER);

        JPanel center = new JPanel(new BorderLayout());
        JLabel currChangeTitle = new JLabel("Current Changes");
        center.add(currChangeTitle, BorderLayout.NORTH);


        JPanel changeList = new JPanel();
        changeList.setLayout(new GridLayout(12,1));
        JScrollPane scrollChanges = new JScrollPane(changeList);

        //Add the changes to the changelist
        for(int i = 0; i < 12; i++) {
            JPanel change1 = new JPanel();
            change1.setLayout(new BorderLayout(50,0));

            JLabel change1File = new JLabel("File: --------------------------------------------");
            JPanel change1Changes = new JPanel(new BorderLayout(0,10));
            change1Changes.add(new JLabel("Changes:"), BorderLayout.NORTH);

            JPanel change1ChangesList = new JPanel();
            change1ChangesList.setLayout(new GridLayout(3, 1));
            change1Changes.add(change1ChangesList, BorderLayout.CENTER);

            for(int j = 0; j < 3; j++){
                change1ChangesList.add(new JLabel("made change to: " + j));
            }

            change1.add(change1File, BorderLayout.CENTER);
            change1.add(change1Changes, BorderLayout.EAST);

            //change1.setMinimumSize(new Dimension(0, 60));
            //change1.setPreferredSize(new Dimension(800, 60));
            //change1.setMaximumSize(new Dimension(1000, 60));
            changeList.add(change1);
        }

        center.add(scrollChanges, BorderLayout.CENTER);

        //center.setPreferredSize(new Dimension(500,500));
        this.getContentPane().add(center, BorderLayout.CENTER);

        MenuBar menuBar = new MenuBar();

        Menu fileMenu = new Menu("File");
        MenuItem fileQuit = new MenuItem("Quit");
        MenuItem fileAbout = new MenuItem("About");
        fileQuit.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent actionEvent) {
                System.exit(0);
            }
        });

        fileMenu.add(fileAbout);
        fileMenu.add(fileQuit);

        menuBar.add(fileMenu);
        setMenuBar(menuBar);
    }
}
